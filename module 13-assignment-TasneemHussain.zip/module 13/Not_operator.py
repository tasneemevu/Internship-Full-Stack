something=True
if not something:
    print("Something is False")
else:
    print("Something is True")


options=['rock', 'paper', 'scissors']
my_answer= input("Choose : rock, paper, scissors: ")

my_answer = my_answer.lower()

if my_answer not in options:
    print("You have entered an invalid option")
else:
    print("You have entered a valid option")