
def order_pizza(name, address, **toppings):



    print(f"Order is for {name}")

    print(f"Ship it to {address}")

    price = 18.00

    for key, value in toppings.items():

        price = price + 2.00

    

    print(f"The total price is {price}")
    return price

total_price = order_pizza("Amanda", "123 Main St", 
                          cheese=True, pepperoni=True, mushrooms=False)


