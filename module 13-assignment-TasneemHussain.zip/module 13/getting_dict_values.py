courses={
    "course":"Python",
    "price":1000,
    "duration":"3 months"
}

if courses.get("curriculum", None):
    print("Curriculum is available")# This checks if the key "curriculum" exists in the dictionary
else:
    print("Curriculum is not available")