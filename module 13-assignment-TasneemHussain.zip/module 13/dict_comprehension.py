numbers=[("name", "Alice"), ("age", 30), ("city", "New York")]

d={key:value for key, value in numbers}

print(d)

print(type(d))
print(type(numbers))