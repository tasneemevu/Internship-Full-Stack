with open ("module 13/read-me.txt", "r") as file:
    content = file.read()
    print(content)

print("Print again:" ,content)  