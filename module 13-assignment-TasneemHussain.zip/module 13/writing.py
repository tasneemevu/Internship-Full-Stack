with open ("module 13/data.txt",'w') as  file:
    file.write("Hello, world!")


with open ("module 13/data.txt",'a')   as file:
    file.write("\n Hello, NEW world!")
    file.write("\n\t Hello, NEW world!")