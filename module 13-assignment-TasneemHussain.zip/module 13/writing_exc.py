import os

filename=input("What is the name of the file? ")
content=input("What is the content of the file? ")

full_path = os.path.join("module 13", filename)

with open(full_path,'w') as file:
    file.write(content)
    
open_file = input("Do you want to open the file? (yes/no) ")

if open_file.lower() == 'yes':
    with open(full_path, 'r') as file:
        print(file.read())
elif open_file.lower() == 'no':
    print("File not opened.")

else:
    print("Invalid input. Please enter 'yes' or 'no'.")