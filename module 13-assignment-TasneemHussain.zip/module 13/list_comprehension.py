numbers= [num**2 for num in [1,2,3,4,5]]
print(numbers)
# This code creates a list of squares of numbers from 1 to 5 using list comprehension.# It iterates through the numbers 1 to 5, squares each number, and collects the