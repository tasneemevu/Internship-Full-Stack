string="I am a string"

print( f'' , string.upper())  # Accessing the upper case of the stringrst character of the string
print(string)

#strings are immutable, so the original string remains unchanged
#if you want to change the string, you need to assign it to a new variable

list=[1,2,3,4,5]
list.append(6)  # Appending to the list
print(list)  # The list is mutable, so it reflects the change

#lists are mutable, so the original list is changed