options=['rock', 'paper', 'scissors']
my_answer= input(" paChoose : rock, paper, scissors: ")
my_answer = my_answer.lower()
if my_answer in options:
    print("It is a valid choice.")
else:
    print("It is not a valid choice.")
