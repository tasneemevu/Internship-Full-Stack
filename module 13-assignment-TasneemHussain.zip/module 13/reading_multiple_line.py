with open("module 13/email.txt", "r") as file:
    lines = file.readlines()
    print(lines)  # Read all lines into a list

for email in lines:
    print(email.rstrip())  # Print each email without extra whitespace

    if "yahoo" in email:
        print("Found a Yahoo email:", email.rstrip())